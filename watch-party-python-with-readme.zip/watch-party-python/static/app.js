const socket = io();
const $ = (id) => document.getElementById(id);
const EMOJIS = ["😂", "❤️", "🔥", "👏", "😮", "😭"];
let myName = "";
let roomCode = "";
let roomState = null;
let movies = [];
let isHost = false;
let ignoreVideoEvents = false;
let toastTimer = null;

const video = $("video");
const showToast = (text) => {
  $("toast").textContent = text;
  $("toast").classList.remove("hidden");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => $("toast").classList.add("hidden"), 3500);
};
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
function fuzzyScore(query, text) {
  const q = query.toLowerCase().trim(), t = text.toLowerCase();
  if (!q) return 1;
  if (t.includes(q)) return 100 - (t.length - q.length);
  let qi = 0, streak = 0, score = 0;
  for (const ch of t) {
    if (ch === q[qi]) { qi++; streak++; score += 2 + streak; } else streak = 0;
    if (qi === q.length) return score;
  }
  return 0;
}
function setNotice(text) { $("landingNotice").textContent = text || ""; }
function enterRoom(code, state) {
  roomCode = code;
  roomState = state;
  $("landing").classList.add("hidden");
  $("watchApp").classList.remove("hidden");
  $("roomPill").classList.remove("hidden");
  $("roomCodeLabel").textContent = code;
  history.replaceState({}, "", `?room=${code}`);
  renderRoom();
  applyPlayback(state.playback, true);
}
function createRoom() {
  myName = $("displayName").value.trim();
  if (!myName) return setNotice("Enter your name first.");
  socket.emit("room:create", { name: myName });
}
function joinRoom() {
  myName = $("displayName").value.trim();
  const code = $("roomCodeInput").value.trim().toUpperCase();
  if (!myName || !code) return setNotice("Enter your name and room code.");
  socket.emit("room:join", { code, name: myName });
}
$("createRoom").addEventListener("click", createRoom);
$("joinRoom").addEventListener("click", joinRoom);
$("roomCodeInput").addEventListener("input", e => e.target.value = e.target.value.toUpperCase());
$("copyInvite").addEventListener("click", async () => {
  try { await navigator.clipboard.writeText(`${location.origin}/?room=${roomCode}`); showToast("Invite link copied."); }
  catch { showToast(`Share this code: ${roomCode}`); }
});

socket.on("connect", () => {
  $("connection").textContent = "● Connected";
  $("footerStatus").textContent = "Connected";
  const inviteCode = new URLSearchParams(location.search).get("room");
  if (inviteCode && !roomCode && myName) socket.emit("room:join", { code: inviteCode, name: myName });
});
socket.on("disconnect", () => {
  $("connection").textContent = "● Reconnecting…";
  $("footerStatus").textContent = "Reconnecting";
  showToast("Connection lost. Trying to reconnect…");
});
socket.on("room:joined", result => {
  if (result?.ok) enterRoom(result.code, result.state);
});
socket.on("room:error", result => setNotice(result?.error || "Room error."));
socket.on("app:error", text => showToast(text));
socket.on("system:message", text => showToast(text));
socket.on("room:state", state => {
  roomState = state;
  if (!roomCode) enterRoom(state.code, state);
  else renderRoom();
});
socket.on("playback:update", update => applyPlayback(update));
socket.on("chat:new", message => {
  if (!roomState) return;
  roomState.chat = [...(roomState.chat || []), message].slice(-100);
  renderChat();
});
socket.on("reaction:new", reaction => {
  if (!roomState) return;
  roomState.reactions = [...(roomState.reactions || []), reaction].slice(-20);
  renderReactions();
});

async function loadMovies() {
  try {
    movies = await (await fetch("/api/movies")).json();
    const categories = ["All", ...new Set(movies.map(m => m.category))];
    $("categoryFilter").innerHTML = categories.map(c => `<option>${esc(c)}</option>`).join("");
    renderMovies();
  } catch { showToast("Could not load movie catalogue."); }
}
function renderMovies() {
  const query = $("movieSearch").value;
  const category = $("categoryFilter").value;
  const filtered = movies.filter(m => category === "All" || m.category === category)
    .map(m => ({ ...m, score: Math.max(fuzzyScore(query, m.title), fuzzyScore(query, `${m.category} ${(m.tags || []).join(" ")}`)) }))
    .filter(m => !query.trim() || m.score > 0).sort((a,b) => b.score-a.score);
  $("movieCount").textContent = `${filtered.length} picks`;
  $("movieGrid").innerHTML = filtered.map((m,i) => `
    <article class="movie-card">
      <div class="movie-art art-${i%4}"><span>${esc(m.category)}</span><b>${esc(m.title.split(" ").slice(0,2).join(" "))}</b><small>${m.year}</small></div>
      <div class="movie-info"><div><strong>${esc(m.title)}</strong><small>${esc(m.category)} · ${m.year}</small></div><button data-add="${esc(m.id)}" title="Add to playlist">＋</button></div>
    </article>`).join("") || `<p class="empty">No matching videos.</p>`;
  document.querySelectorAll("[data-add]").forEach(btn => btn.addEventListener("click", () => {
    const movie = movies.find(m => m.id === btn.dataset.add);
    if (!movie) return;
    socket.emit("playlist:add", { code: roomCode, movie });
    if (isHost) sendPlayback("load", { videoUrl: movie.url, currentTime: 0 });
  }));
}
$("movieSearch").addEventListener("input", renderMovies);
$("categoryFilter").addEventListener("change", renderMovies);

function renderRoom() {
  if (!roomState) return;
  isHost = roomState.hostId === socket.id;
  $("hostLabel").textContent = isHost ? "★ YOU'RE HOST" : `HOST: ${roomState.users.find(u => u.id === roomState.hostId)?.name || "reconnecting"}`;
  $("transferHost").classList.toggle("hidden", !isHost);
  $("guestOverlay").classList.toggle("hidden", isHost);
  video.controls = isHost;
  $("peopleCount").textContent = `${roomState.users.length} people`;
  $("peopleList").innerHTML = roomState.users.map((u,i) => `
    <div class="person"><span class="avatar color-${i%4}">${esc(u.name[0]?.toUpperCase())}</span><span>${esc(u.name)}${u.id===socket.id?" (you)":""}</span>${u.id===roomState.hostId?"<small>HOST</small>":""}${isHost&&u.id!==socket.id?`<button data-host="${esc(u.id)}" title="Make host">⇄</button>`:""}</div>`).join("");
  document.querySelectorAll("[data-host]").forEach(btn => btn.addEventListener("click", () => socket.emit("host:transfer", { code: roomCode, targetId: btn.dataset.host })));
  $("queueCount").textContent = `${roomState.playlist.length} queued`;
  $("playlist").innerHTML = roomState.playlist.length ? roomState.playlist.map((m,i) => `
    <div class="queue-item"><span class="queue-number">${String(i+1).padStart(2,"0")}</span><div><strong>${esc(m.title)}</strong><small>Added by ${esc(m.addedBy)}</small></div>${isHost?`<button data-remove="${esc(m.id)}">×</button>`:""}</div>`).join("") : `<p class="empty">Your shared queue is empty. Add a pick from Discover.</p>`;
  document.querySelectorAll("[data-remove]").forEach(btn => btn.addEventListener("click", () => socket.emit("playlist:remove", { code: roomCode, id: btn.dataset.remove })));
  renderChat(); renderReactions(); renderPolls();
}
function renderChat() {
  $("chatMessages").innerHTML = (roomState?.chat || []).slice(-30).map(m => `<div class="chat-message"><b>${esc(m.name)}</b><p>${esc(m.text)}</p></div>`).join("");
  $("chatMessages").scrollTop = $("chatMessages").scrollHeight;
}
$("chatForm").addEventListener("submit", e => {
  e.preventDefault();
  const text = $("chatInput").value.trim();
  if (!text) return;
  socket.emit("chat:send", { code: roomCode, text });
  $("chatInput").value = "";
});
function renderReactions() {
  $("recentReactions").innerHTML = (roomState?.reactions || []).slice(-4).map(r => `<span title="${esc(r.name)}">${esc(r.emoji)}</span>`).join("");
}
$("emojiButtons").innerHTML = EMOJIS.map(e => `<button data-emoji="${e}">${e}</button>`).join("");
document.querySelectorAll("[data-emoji]").forEach(btn => btn.addEventListener("click", () => socket.emit("reaction:send", { code: roomCode, emoji: btn.dataset.emoji })));
$("pollForm").addEventListener("submit", e => {
  e.preventDefault();
  const question = $("pollQuestion").value.trim();
  const options = $("pollOptions").value.split(",").map(s => s.trim()).filter(Boolean);
  socket.emit("poll:create", { code: roomCode, question, options });
  $("pollQuestion").value = "";
});
function renderPolls() {
  $("polls").innerHTML = (roomState?.polls || []).slice(-2).map(p => `
    <div class="poll"><strong>${esc(p.question)}</strong>${p.options.map(o => `<button class="poll-option" data-poll="${esc(p.id)}" data-option="${esc(o.id)}"><span>${esc(o.label)}</span><span>${o.votes.length} votes</span></button>`).join("")}</div>`).join("");
  document.querySelectorAll("[data-poll]").forEach(btn => btn.addEventListener("click", () => socket.emit("poll:vote", { code: roomCode, pollId: btn.dataset.poll, optionId: btn.dataset.option })));
}
$("transferHost").addEventListener("click", () => {
  const next = roomState?.users.find(u => u.id !== socket.id);
  if (next) socket.emit("host:transfer", { code: roomCode, targetId: next.id });
});

function sendPlayback(action, extra = {}) {
  socket.emit("playback:command", { code: roomCode, action, currentTime: video.currentTime || 0, clientSentAt: Date.now(), ...extra });
}
video.addEventListener("play", () => { if (isHost && !ignoreVideoEvents) sendPlayback("play"); });
video.addEventListener("pause", () => { if (isHost && !ignoreVideoEvents && !video.ended) sendPlayback("pause"); });
video.addEventListener("seeked", () => { if (isHost && !ignoreVideoEvents) sendPlayback("seek"); });

function applyPlayback(update, initial = false) {
  if (!update || !video) return;
  const url = update.videoUrl;
  ignoreVideoEvents = true;
  if (url && video.src !== url) video.src = url;
  const referenceTime = update.updatedAt || update.serverTime || Date.now();
  const expected = Number(update.currentTime || 0) + (update.playing ? Math.max(0, (Date.now() - referenceTime) / 1000) : 0);
  if (initial || Math.abs((video.currentTime || 0) - expected) > 0.5) {
    try { video.currentTime = expected; } catch {}
  }
  if (update.playing) video.play().catch(() => showToast("Browser blocked autoplay. Press play once to enable playback."));
  else video.pause();
  const title = movies.find(m => m.url === url)?.title || "Shared video";
  $("videoTitle").textContent = title;
  setTimeout(() => { ignoreVideoEvents = false; }, 150);
}
setInterval(() => {
  if (!roomState?.playback || isHost || video.readyState < 2) return;
  const p = roomState.playback;
  const expected = Number(p.currentTime || 0) + (p.playing ? Math.max(0, (Date.now() - p.updatedAt) / 1000) : 0);
  if (Math.abs(video.currentTime - expected) > 0.5) {
    ignoreVideoEvents = true;
    video.currentTime = expected;
    setTimeout(() => { ignoreVideoEvents = false; }, 150);
  }
}, 1500);

loadMovies();
